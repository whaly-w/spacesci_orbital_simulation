import pygame, sys
from button import Button

pygame.init()

SCREEN = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Menu")

BG = pygame.image.load("assets/bg.jpg")
galaxyBG = pygame.image.load("assets/galaxy.jpg")
galaxy2 = pygame.image.load("assets/galaxy2.jpg")

# Dictionary to map planet names to their respective image files
# You'll need to add these images to your assets folder
PLANET_IMAGES = {
    "Earth": "assets/earth.png",
    "Venus": "assets/venus.png",
    "Mars": "assets/mars.png",
    "Jupiter": "assets/jupiter.png",
    "Saturn": "assets/saturn.png",
    "Mercury": "assets/mercury.png",
    "Uranus": "assets/uranus.png",
    "Neptune": "assets/neptune.png"
}

# Load planet images
planet_image_surfaces = {}
try:
    for planet, img_path in PLANET_IMAGES.items():
        planet_image_surfaces[planet] = pygame.image.load(img_path)
        # Resize images to a consistent size (150x150 pixels)
        planet_image_surfaces[planet] = pygame.transform.scale(planet_image_surfaces[planet], (150, 150))
except pygame.error as e:
    print(f"Warning: Could not load some planet images: {e}")
    # Create placeholder images for missing planets
    for planet in PLANET_IMAGES:
        if planet not in planet_image_surfaces:
            # Create a colored circle as a placeholder
            surf = pygame.Surface((150, 150), pygame.SRCALPHA)
            color = (255, 0, 0) if planet == "Mars" else (
                    (255, 255, 0) if planet == "Venus" else (
                    (222, 184, 135) if planet == "Mercury" else (
                    (255, 140, 0) if planet == "Jupiter" else (
                    (210, 180, 140) if planet == "Saturn" else (0, 0, 255)))))
            pygame.draw.circle(surf, color, (75, 75), 70)
            planet_image_surfaces[planet] = surf

def get_font(size):  # Returns font in the desired size
    return pygame.font.Font("assets/Nexa-ExtraLight.ttf", size)

# Dropdown class to handle dropdown behavior
class Dropdown:
    def __init__(self, pos, options, font, base_color, hovering_color, label="Select Option"):
        self.pos = pos
        self.options = options
        self.font = font
        self.base_color = base_color
        self.hovering_color = hovering_color
        self.dropdown_open = False
        self.buttons = []
        self.selected_option = None
        self.label = label
        
        # Create buttons for each option
        for i, option in enumerate(options):
            self.buttons.append(Button(image=None, pos=(self.pos[0], self.pos[1] + (i + 1) * 50),
                                       text_input=option, font=self.font, base_color=self.base_color, 
                                       hovering_color=self.hovering_color))

    def toggle(self):
        """Toggle the dropdown visibility."""
        self.dropdown_open = not self.dropdown_open

    def handle_event(self, event, mouse_pos):
        """Handle events and check for button clicks."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.dropdown_open:
                for i, button in enumerate(self.buttons):
                    if button.checkForInput(mouse_pos):
                        self.selected_option = self.options[i]
                        self.toggle()  # Close dropdown after selection
                        return True
            else:
                # If dropdown button clicked, toggle the dropdown
                if self.dropdown_button.checkForInput(mouse_pos):
                    self.toggle()
                    # Close other dropdowns (could be implemented better with a reference to all dropdowns)
                    return True

        return False

    def draw(self, screen, mouse_pos):
        """Draw the dropdown button and options."""
        # Draw the dropdown button
        self.dropdown_button = Button(image=None, pos=self.pos, text_input=self.label, 
                                      font=self.font, base_color=self.base_color, hovering_color=self.hovering_color)
        self.dropdown_button.changeColor(mouse_pos)
        self.dropdown_button.update(screen)

        if self.dropdown_open:
            # Draw options if the dropdown is open
            for button in self.buttons:
                button.changeColor(mouse_pos)
                button.update(screen)

        return self.selected_option


# Play screen function
def play():
    # List of planets for both dropdowns
    planets = ["Earth", "Venus", "Mars", "Jupiter", "Saturn", "Mercury", "Uranus", "Neptune"]
    
    # SWAPPED: Dropdown for origin planet (now on left)
    origin_dropdown = Dropdown(
        pos=(440, 250), 
        options=planets, 
        font=get_font(40), 
        base_color="White", 
        hovering_color="Blue",
        label="Origin Planet"
    )
    
    # SWAPPED: Dropdown for destination planet (now on right)
    destination_dropdown = Dropdown(
        pos=(840, 250), 
        options=planets, 
        font=get_font(40), 
        base_color="White", 
        hovering_color="Green",
        label="Destination Planet"
    )

    while True:
        SCREEN.blit(galaxyBG, (0, 0))  # Draw galaxy background

        PLAY_MOUSE_POS = pygame.mouse.get_pos()

        PLAY_TEXT = get_font(45).render("Set your journey coordinates.", True, "White")
        PLAY_RECT = PLAY_TEXT.get_rect(center=(640, 100))
        SCREEN.blit(PLAY_TEXT, PLAY_RECT)

        PLAY_BACK = Button(image=None, pos=(640, 650), 
                           text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")
        PLAY_BACK.changeColor(PLAY_MOUSE_POS)
        PLAY_BACK.update(SCREEN)

        # Draw the dropdowns
        selected_origin = origin_dropdown.draw(SCREEN, PLAY_MOUSE_POS)
        selected_destination = destination_dropdown.draw(SCREEN, PLAY_MOUSE_POS)
        
        # Display planet images - positions swapped
        if selected_origin:
            # Display origin planet image on the left
            origin_img = planet_image_surfaces.get(selected_origin)
            origin_img_rect = origin_img.get_rect(center=(440, 400))
            SCREEN.blit(origin_img, origin_img_rect)
            
            # Display origin text below the image
            origin_text = get_font(25).render(f"Origin: {selected_origin}", True, "White")
            origin_text_rect = origin_text.get_rect(center=(440, 480))
            SCREEN.blit(origin_text, origin_text_rect)
            
        if selected_destination:
            # Display destination planet image on the right
            dest_img = planet_image_surfaces.get(selected_destination)
            dest_img_rect = dest_img.get_rect(center=(840, 400))
            SCREEN.blit(dest_img, dest_img_rect)
            
            # Display destination text below the image
            dest_text = get_font(25).render(f"Destination: {selected_destination}", True, "White")
            dest_text_rect = dest_text.get_rect(center=(840, 480))
            SCREEN.blit(dest_text, dest_text_rect)
        
        # Show start button only when both options are selected and they're different
        valid_selection = selected_origin and selected_destination and selected_origin != selected_destination
        
        if valid_selection:
            # Draw a line between the planets to represent the journey
            pygame.draw.line(SCREEN, (255, 255, 255), (490, 400), (790, 400), 3)
            # Add some arrow heads to show direction
            pygame.draw.polygon(SCREEN, (255, 255, 255), [(780, 390), (790, 400), (780, 410)])
            
            START_BUTTON = Button(image=None, pos=(640, 580), 
                                  text_input="Calculate Speed", font=get_font(50), base_color="#00ff44", hovering_color="White")
            START_BUTTON.changeColor(PLAY_MOUSE_POS)
            START_BUTTON.update(SCREEN)
        elif selected_origin and selected_destination and selected_origin == selected_destination:
            # Show error message if same planet selected
            error_text = get_font(25).render("Origin and destination cannot be the same!", True, "#ff5555")
            error_rect = error_text.get_rect(center=(640, 530))
            SCREEN.blit(error_text, error_rect)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BACK.checkForInput(PLAY_MOUSE_POS):
                    main_menu()  # Go back to the main menu
                
                # Only check for START_BUTTON if it exists (both options selected and valid)
                if valid_selection:
                    if START_BUTTON.checkForInput(PLAY_MOUSE_POS):
                        # Call the calculate function with the selected planets
                        calculate(selected_origin, selected_destination)
                
                # Handle dropdown events
                if destination_dropdown.handle_event(event, PLAY_MOUSE_POS):
                    # If destination dropdown was toggled, close origin dropdown
                    origin_dropdown.dropdown_open = False
                
                if origin_dropdown.handle_event(event, PLAY_MOUSE_POS):
                    # If origin dropdown was toggled, close destination dropdown
                    destination_dropdown.dropdown_open = False

        pygame.display.update()
        
def calculate(origin_planet=None, destination_planet=None):
    while True:
        CAL_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.blit(galaxy2, (0, 0))

        # Display the calculation title
        CAL_TEXT = get_font(45).render("Speed Calculation", True, "White")
        CAL_RECT = CAL_TEXT.get_rect(center=(640, 100))
        SCREEN.blit(CAL_TEXT, CAL_RECT)

        # If planets were passed, display them and calculate the speed
        if origin_planet and destination_planet:
            # Display the journey information
            JOURNEY_TEXT = get_font(30).render(f"Journey: {origin_planet} → {destination_planet}", True, "White")
            JOURNEY_RECT = JOURNEY_TEXT.get_rect(center=(640, 180))
            SCREEN.blit(JOURNEY_TEXT, JOURNEY_RECT)
            
            # Simple placeholder speed calculation (you'll replace this with your actual algorithm)
            # For example purposes only:
            planet_distances = {
                "Mercury": 0.39,  # AU from Sun
                "Venus": 0.72,
                "Earth": 1.00,
                "Mars": 1.52,
                "Jupiter": 5.20,
                "Saturn": 9.58,
                "Uranus": 19.18, 
                "Neptune": 30.07
            }



#----------------------------------------------------------For Calcualtion-------------------------------------------------------------------------------------------------------
            # Calculate distance (this is a simplified example)
            distance = abs(planet_distances[destination_planet] - planet_distances[origin_planet])
            speed = distance * 30000  # km/s (just a sample calculation)
            
            # Display the calculation results
            DISTANCE_TEXT = get_font(25).render(f"Distance: {distance:.2f} AU", True, "White")
            DISTANCE_RECT = DISTANCE_TEXT.get_rect(center=(640, 250))
            SCREEN.blit(DISTANCE_TEXT, DISTANCE_RECT)
            
            SPEED_TEXT = get_font(35).render(f"Required Speed: {speed:.2f} km/s", True, "#DD0000")
            SPEED_RECT = SPEED_TEXT.get_rect(center=(640, 320))
            SCREEN.blit(SPEED_TEXT, SPEED_RECT)
 #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




            # Display planet images
            if origin_planet in planet_image_surfaces and destination_planet in planet_image_surfaces:
                # Scale images to smaller size for this screen
                origin_img = pygame.transform.scale(planet_image_surfaces[origin_planet], (100, 100))
                dest_img = pygame.transform.scale(planet_image_surfaces[destination_planet], (100, 100))
                
                # Position the images
                SCREEN.blit(origin_img, origin_img.get_rect(center=(300, 400)))
                SCREEN.blit(dest_img, dest_img.get_rect(center=(980, 400)))
                
                # Draw arrow connecting the planets
                pygame.draw.line(SCREEN, (255, 255, 255), (350, 400), (930, 400), 3)
                pygame.draw.polygon(SCREEN, (255, 255, 255), [(920, 390), (930, 400), (920, 410)])

        # Back button
        CAL_BACK = Button(image=None, pos=(640, 500), 
                            text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")

        CAL_BACK.changeColor(CAL_MOUSE_POS)
        CAL_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if CAL_BACK.checkForInput(CAL_MOUSE_POS):
                    main_menu()

        pygame.display.update()

# Main menu function
def main_menu():
    while True:
        # Background
        SCREEN.blit(BG, (0, 0))
        # Get mouse position
        MENU_MOUSE_POS = pygame.mouse.get_pos()
        # Create text "welcome"
        MENU_TEXT = get_font(100).render("WELCOME", True, "#FFFFFF")
        MENU_RECT = MENU_TEXT.get_rect(center=(640, 100))

        PLAY_BUTTON = Button(image=pygame.image.load("assets/Play Rect.png"), pos=(640, 600), 
                             text_input="PLAY", font=get_font(75), base_color="#ecff00", hovering_color="White")
 
        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()  # Start the play screen

        pygame.display.update()

# Start the game at the main menu
main_menu()